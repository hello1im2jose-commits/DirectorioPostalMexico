package mx.directoriopostal

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Green = Color(0xFF176B50)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFFDAA520))) { PostalApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostalApp() {
    val context = LocalContext.current
    val db = remember { PostalDatabase(context) }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selectedState by remember { mutableStateOf("Todos los estados") }
    var states by remember { mutableStateOf(listOf<String>()) }
    var results by remember { mutableStateOf(listOf<PostalRecord>()) }
    var total by remember { mutableIntStateOf(0) }
    var importing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    fun refresh() {
        total = db.count(); states = db.states()
        results = db.search(query, selectedState)
    }
    LaunchedEffect(Unit) { refresh() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            importing = true
            scope.launch {
                val imported = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { db.importSepomex(it) } ?: 0
                }
                importing = false
                message = if (imported > 0) "Catálogo importado: $imported registros." else "No se pudo importar el archivo. Verifica que sea el TXT de SEPOMEX."
                refresh()
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Column {
        Text("Directorio Postal México", fontWeight = FontWeight.Bold)
        Text("Consulta nacional de códigos postales", style = MaterialTheme.typography.labelSmall)
    } }, actions = { IconButton(onClick = { picker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) }) { Icon(Icons.Default.FileOpen, "Importar catálogo") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF4EF)), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Directorio nacional", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(if (total > 0) "$total registros cargados · ${states.size} entidades" else "Aún no hay datos cargados", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { picker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) }, enabled = !importing, modifier = Modifier.fillMaxWidth()) {
                        if (importing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        else Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(8.dp)); Text(if (importing) "Importando catálogo…" else "Cargar catálogo oficial SEPOMEX")
                    }
                }
            }
            OutlinedTextField(value = query, onValueChange = { query = it; results = db.search(it, selectedState) }, modifier = Modifier.fillMaxWidth(), label = { Text("Código postal, colonia, municipio o estado") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(value = selectedState, onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("Filtrar por estado") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    (listOf("Todos los estados") + states).forEach { state ->
                        DropdownMenuItem(text = { Text(state) }, onClick = { selectedState = state; expanded = false; results = db.search(query, state) })
                    }
                }
            }
            if (message.isNotBlank()) { Text(message, color = Green, style = MaterialTheme.typography.bodySmall) }
            Text(if (results.isEmpty()) "Sin resultados" else "Resultados (${results.size}${if (results.size == 250) "+" else ""})", fontWeight = FontWeight.SemiBold)
            if (total == 0) {
                Text("Para comenzar, descarga el catálogo nacional en formato TXT desde el portal oficial de Correos de México y cárgalo aquí. Después podrás consultar toda la información sin Internet.", style = MaterialTheme.typography.bodyMedium)
                Text("El archivo debe ser el TXT delimitado por | (barra vertical), no el Excel.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results) { item ->
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(item.postalCode, color = Green, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text(item.settlement, fontWeight = FontWeight.SemiBold)
                                Text(listOf(item.settlementType, item.municipality, item.state).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                                if (item.city.isNotBlank()) Text("Ciudad: ${item.city}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}
