package mx.directoriopostal

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class PostalRecord(
    val postalCode: String,
    val settlement: String,
    val settlementType: String,
    val municipality: String,
    val state: String,
    val city: String
)

class PostalDatabase(context: Context) : SQLiteOpenHelper(context, "directorio_postal.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE postal (id INTEGER PRIMARY KEY, cp TEXT NOT NULL, asentamiento TEXT NOT NULL, tipo TEXT, municipio TEXT, estado TEXT, ciudad TEXT)")
        db.execSQL("CREATE INDEX idx_cp ON postal(cp)")
        db.execSQL("CREATE INDEX idx_estado ON postal(estado)")
        db.execSQL("CREATE INDEX idx_municipio ON postal(municipio)")
        db.execSQL("CREATE INDEX idx_asentamiento ON postal(asentamiento)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun importSepomex(input: java.io.InputStream): Int {
        val db = writableDatabase
        db.beginTransaction()
        var count = 0
        try {
            db.delete("postal", null, null)
            input.bufferedReader(Charsets.ISO_8859_1).useLines { lines ->
                lines.drop(1).forEach { line ->
                    val f = line.split('|')
                    if (f.size >= 6) {
                        val cp = f[0].trim().trim('\uFEFF')
                        if (cp.matches(Regex("\\d{5}"))) {
                            val values = ContentValues().apply {
                                put("cp", cp); put("asentamiento", f[1].trim()); put("tipo", f[2].trim())
                                put("municipio", f[3].trim()); put("estado", f[4].trim()); put("ciudad", f[5].trim())
                            }
                            db.insert("postal", null, values); count++
                        }
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return count
    }

    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM postal", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun states(): List<String> = readableDatabase.rawQuery("SELECT DISTINCT estado FROM postal ORDER BY estado", null).use { c ->
        buildList { while (c.moveToNext()) add(c.getString(0)) }
    }

    fun search(query: String, state: String?, limit: Int = 250): List<PostalRecord> {
        val q = query.trim()
        val clauses = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (q.isNotEmpty()) {
            clauses += "(cp LIKE ? OR asentamiento LIKE ? OR municipio LIKE ? OR estado LIKE ? OR ciudad LIKE ?)"
            repeat(5) { args += "%$q%" }
        }
        if (!state.isNullOrBlank() && state != "Todos los estados") { clauses += "estado = ?"; args += state }
        val where = if (clauses.isEmpty()) "" else "WHERE " + clauses.joinToString(" AND ")
        val sql = "SELECT cp, asentamiento, tipo, municipio, estado, ciudad FROM postal $where ORDER BY cp, asentamiento LIMIT $limit"
        return readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            buildList { while (c.moveToNext()) add(PostalRecord(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5))) }
        }
    }
}
