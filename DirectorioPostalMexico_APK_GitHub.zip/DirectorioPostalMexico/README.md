# Directorio Postal México (Android)

Proyecto Android nativo en Kotlin + Jetpack Compose. Permite importar el catálogo TXT de SEPOMEX, guardarlo en SQLite y consultarlo completamente sin conexión.

## Funciones
- Búsqueda por código postal, asentamiento/colonia, municipio, ciudad o estado.
- Filtro por las 32 entidades federativas presentes en el archivo importado.
- Ficha de cada asentamiento: CP, nombre, tipo, municipio, estado y ciudad.
- Base local SQLite e índices para búsquedas rápidas.
- Importación del catálogo desde el almacenamiento del teléfono.

## Cargar la base postal
1. Abre el portal oficial: https://www.correosdemexico.gob.mx/sslservicios/consultacp/CodigoPostal_Exportar.aspx
2. Selecciona la opción de todo el país y el formato **TXT**.
3. Descarga el archivo en tu teléfono.
4. Abre Directorio Postal México y pulsa **Cargar catálogo oficial SEPOMEX**.
5. Selecciona el TXT descargado. La importación se realiza una sola vez; después las consultas funcionan sin Internet.

El importador espera el formato oficial delimitado por `|` y la codificación Latin-1/ISO-8859-1. Mantiene los códigos postales como texto para conservar ceros iniciales.

## Compilar APK
1. Abre esta carpeta en Android Studio (Hedgehog o posterior).
2. Permite que Gradle sincronice las dependencias.
3. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Fuente y condiciones de los datos
Fuente: Servicio Postal Mexicano (SEPOMEX), Catálogo Nacional de Códigos Postales. Consulta siempre el aviso y las condiciones vigentes en el portal oficial. El portal indica que el catálogo se proporciona gratuitamente y que no está permitida su comercialización total o parcial.

## Alcance
El catálogo postal incluye asentamientos y sus datos postales. No debe confundirse con un callejero: no contiene necesariamente calles, números exteriores/interiores ni coordenadas.
